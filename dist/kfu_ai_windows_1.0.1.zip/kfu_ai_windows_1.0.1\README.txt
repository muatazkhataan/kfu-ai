﻿# KFU AI Assistant
Version: 1.0.1

## System Requirements
- Windows 10 or later (64-bit)
- No need to install Flutter or Dart

## Installation
1. Extract all files from this folder
2. Run kfu_ai.exe
3. Do not delete any files

## Contents
- kfu_ai.exe: Main application
- *.dll: Required libraries
- data/: Data, fonts, and icons

## Notes
- All fonts and icons are included
- Application works independently

---
Build Date: 2025-11-24 09:56:30
